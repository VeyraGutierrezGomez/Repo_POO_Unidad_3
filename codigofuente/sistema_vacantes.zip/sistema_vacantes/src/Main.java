import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;
import java.util.function.Supplier;

/**
 * Main.java — versión con hilos manuales, colas compartidas y notificaciones en tiempo real.
 * Mantiene el diseño original (login, empresa, postulante, admin) y agrega concurrencia:
 * - Empresas publican vacantes en paralelo.
 * - Postulantes buscan/aplican en paralelo.
 * - Cola compartida de vacantes y de solicitudes de aplicación.
 * - Notificaciones al empleador via EventBus + EDT.
 * - Consultas a DB fuera del hilo de UI.
 */
public class Main extends JFrame {

    // CardLayout para cambiar paneles
    private JPanel mainPanel;
    private CardLayout cardLayout;

    SafeQueue<VacantePublicado> colaVacantes = new SafeQueue<>();
    SafeQueue<SolicitudAplicacion> colaSolicitudes = new SafeQueue<>();
    Map<Integer, SafeQueue<Notificacion>> notificacionesUsuarios = new HashMap<>();



    // Paneles
    private JPanel loginPanel, empresaPanel, postulantePanel, adminPanel;

    // Variables de sesión
    private int usuarioId;
    private String tipoUsuario;

    // Constantes y campo de conexión
    private static final String DB_URL = "jdbc:mysql://localhost:3306/sistema_vacantes";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private Connection conn = null;

    // --------------- Concurrencia/Queues/Eventos ----------------
    // Colas compartidas (implementación propia con wait/notify)
   private final EventBus eventBus = new EventBus();

    // Control de ciclo de vida de hilos
    private final List<Thread> workers = Collections.synchronizedList(new ArrayList<>());
    private volatile boolean running = true;

    // ------------------------ CONEXIÓN ------------------------
    private Connection conectarDB() throws SQLException {
        if (this.conn != null && !this.conn.isClosed()) {
            return this.conn;
        }
        this.conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        // para operaciones agrupadas opcionalmente
        try { this.conn.setAutoCommit(true); } catch (SQLException ignored) {}
        System.out.println("Conectado a la DB");
        return this.conn;
    }

    private Connection getConn() throws SQLException {
        if (this.conn == null || this.conn.isClosed()) {
            this.conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            this.conn.setAutoCommit(true);
        }
        return this.conn;
    }

    // ------------------------ CONSTRUCTOR ------------------------
    public Main() {
        // Config ventana
        setTitle("Sistema de Vacantes");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);



        // Conectar DB
        try {
            conectarDB();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + ex.getMessage());
            System.exit(1);
        }

        // Configurar CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel);

        // Crear paneles
        crearLoginPanel();
        crearEmpresaPanel();
        crearPostulantePanel();
        crearAdminPanel();

        // Suscribir notificaciones del empleador al bus de eventos
        eventBus.subscribe("nueva-aplicacion", payload -> {
            if (!(payload instanceof SolicitudAplicacion sa)) return;
            // Mostrar notificación en EDT
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(
                        Main.this,
                        "Nueva solicitud de aplicación #" + sa.idAplicacion +
                                " del postulante " + sa.idPostulante +
                                " a la vacante #" + sa.idVacante,
                        "Notificación (Empresa)", JOptionPane.INFORMATION_MESSAGE
                );
                // Intentar refrescar tablas de aplicaciones en panel empresa/admin
                refrescarTablasEmpresaYAdmin();
            });
        });

        // Iniciar simulación concurrente (puedes comentar si no quieres simular)
        startConcurrencySimulation();

        setVisible(true);
    }


    // ------------------------ LOGIN ------------------------
    private void crearLoginPanel() {
        loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);

        JLabel lblEmail = new JLabel("Usuario:");
        JLabel lblPassword = new JLabel("Contraseña:");
        JTextField txtEmail = new JTextField(20);
        JPasswordField txtPassword = new JPasswordField(20);
        JButton btnLogin = new JButton("Iniciar Sesión");

        c.gridx = 0; c.gridy = 0; loginPanel.add(lblEmail, c);
        c.gridx = 1; loginPanel.add(txtEmail, c);
        c.gridx = 0; c.gridy = 1; loginPanel.add(lblPassword, c);
        c.gridx = 1; loginPanel.add(txtPassword, c);
        c.gridx = 0; c.gridy = 2; c.gridwidth = 2; loginPanel.add(btnLogin, c);

        btnLogin.addActionListener(e -> {
            String email = txtEmail.getText();
            String password = new String(txtPassword.getPassword());
            // Hacer login fuera del EDT
            new Thread(() -> loginUsuario(email, password)).start();
        });

        mainPanel.add(loginPanel, "login");
        cardLayout.show(mainPanel, "login");
    }


    // Verifica si la vacante pertenece a la empresa con idEmpresa
    private boolean empresaTieneVacante(int idEmpresa, int idVacante) {
        try (Connection c = getConn()) {
            if (c != null) {
                String sql = "SELECT COUNT(*) FROM vacantes WHERE id_vacante = ? AND empresa_id = ?";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setInt(1, idVacante);
                    ps.setInt(2, idEmpresa);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            return rs.getInt(1) > 0; // >0 significa que la vacante pertenece a la empresa
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    private void loginUsuario(String email, String password) {
        try {
            PreparedStatement ps = getConn().prepareStatement(
                    "SELECT id_usuario, tipo_usuario FROM usuarios WHERE email=? AND password=?"
            );
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                usuarioId = rs.getInt("id_usuario");
                tipoUsuario = rs.getString("tipo_usuario");
                SwingUtilities.invokeLater(() -> {
                    switch (tipoUsuario) {
                        case "empresa" -> cardLayout.show(mainPanel, "empresa");
                        case "postulante" -> cardLayout.show(mainPanel, "postulante");
                        case "admin" -> cardLayout.show(mainPanel, "admin");
                        default -> JOptionPane.showMessageDialog(this, "Tipo de usuario desconocido");
                    }
                });
            } else {
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() ->
                    JOptionPane.showMessageDialog(this, "Error al iniciar sesión: " + e.getMessage()));
        }
    }

    // ------------------------ PANEL EMPRESA ------------------------
    private void crearEmpresaPanel() {
        empresaPanel = new JPanel(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();

        // --- PERFIL EMPRESA (solo lectura) ---
        JPanel perfilPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);

        JLabel lblNombre = new JLabel();      c.gridx=1; c.gridy=0; perfilPanel.add(lblNombre, c);
        JLabel lblRazon = new JLabel();       c.gridx=1; c.gridy=1; perfilPanel.add(lblRazon, c);
        JLabel lblSector = new JLabel();      c.gridx=1; c.gridy=2; perfilPanel.add(lblSector, c);
        JLabel lblRfc = new JLabel();         c.gridx=1; c.gridy=3; perfilPanel.add(lblRfc, c);
        JLabel lblTelefono = new JLabel();    c.gridx=1; c.gridy=4; perfilPanel.add(lblTelefono, c);
        JLabel lblDireccion = new JLabel();   c.gridx=1; c.gridy=5; perfilPanel.add(lblDireccion, c);
        JLabel lblWeb = new JLabel();         c.gridx=1; c.gridy=6; perfilPanel.add(lblWeb, c);

        // Botón cerrar sesión
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        c.gridy=7; perfilPanel.add(btnCerrarSesion, c);

        btnCerrarSesion.addActionListener(e -> {
            usuarioId = -1;
            mostrarLoginPanel();
        });

        tabbedPane.add("Perfil", perfilPanel);

        // --- VACANTES ---
        JPanel vacantesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelVacantes = new DefaultTableModel();
        JTable tableVacantes = new JTable(modelVacantes);
        modelVacantes.setColumnIdentifiers(new String[]{"ID","Titulo","Salario Min","Salario Max","Ubicación","Modalidad","Estado"});
        vacantesPanel.add(new JScrollPane(tableVacantes), BorderLayout.CENTER);

        JPanel panelBotonesVacantes = new JPanel();
        JButton btnNuevaVacante = new JButton("Agregar Vacante");
        JButton btnRefrescarVacantes = new JButton("Refrescar");
        panelBotonesVacantes.add(btnNuevaVacante);
        panelBotonesVacantes.add(btnRefrescarVacantes);
        vacantesPanel.add(panelBotonesVacantes, BorderLayout.SOUTH);

        btnNuevaVacante.addActionListener(e -> mostrarDialogoNuevaVacante(modelVacantes));
        btnRefrescarVacantes.addActionListener(e ->
                new Thread(() -> cargarVacantesEmpresa(modelVacantes)).start());

        tabbedPane.add("Vacantes", vacantesPanel);

        // --- APLICACIONES ---
        JPanel aplicacionesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelApps = new DefaultTableModel();
        JTable tableApps = new JTable(modelApps);
        modelApps.setColumnIdentifiers(new String[]{"ID Aplicación","Postulante","Vacante","Estado"});
        aplicacionesPanel.add(new JScrollPane(tableApps), BorderLayout.CENTER);

        JPanel panelBotonesApps = new JPanel();
        JButton btnRechazarPostulante = new JButton("Rechazar");
        JButton btnAceptarPostulante = new JButton("Aceptar");
        JButton btnRefrescarApps = new JButton("Refrescar");
        panelBotonesApps.add(btnRechazarPostulante);
        panelBotonesApps.add(btnAceptarPostulante);
        panelBotonesApps.add(btnRefrescarApps);
        aplicacionesPanel.add(panelBotonesApps, BorderLayout.SOUTH);

        btnRechazarPostulante.addActionListener(e ->
                new Thread(() -> rechazarPostulante(tableApps, modelApps)).start());
        btnAceptarPostulante.addActionListener(e ->
                new Thread(() -> aceptarPostulante(tableApps, modelApps)).start());
        btnRefrescarApps.addActionListener(e ->
                new Thread(() -> cargarAplicacionesEmpresa(modelApps)).start());

        tabbedPane.add("Aplicaciones", aplicacionesPanel);

        empresaPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(empresaPanel, "empresa");
    }

    private void mostrarLoginPanel() {
        CardLayout cl = (CardLayout) mainPanel.getLayout();
        cl.show(mainPanel, "login");
    }

    private int getIdEmpresa() throws SQLException {
        try (PreparedStatement ps = getConn().prepareStatement(
                "SELECT id_empresa FROM empresas WHERE id_usuario=?")) {
            ps.setInt(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("id_empresa") : -1;
            }
        }
    }

    private void mostrarDialogoNuevaVacante(DefaultTableModel model) {
        JDialog dialog = new JDialog(this, "Nueva Vacante", true);
        dialog.setSize(400, 500);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);

        // Campos de la vacante
        c.gridx=0;c.gridy=0; dialog.add(new JLabel("Título:"), c);
        JTextField txtTitulo = new JTextField(20); c.gridx=1; dialog.add(txtTitulo, c);

        c.gridx=0;c.gridy=1; dialog.add(new JLabel("Descripción:"), c);
        JTextArea txtDesc = new JTextArea(3,20); c.gridx=1; dialog.add(new JScrollPane(txtDesc), c);

        c.gridx=0;c.gridy=2; dialog.add(new JLabel("Requisitos:"), c);
        JTextArea txtReq = new JTextArea(3,20); c.gridx=1; dialog.add(new JScrollPane(txtReq), c);

        c.gridx=0;c.gridy=3; dialog.add(new JLabel("Salario Min:"), c);
        JTextField txtMin = new JTextField(10); c.gridx=1; dialog.add(txtMin, c);

        c.gridx=0;c.gridy=4; dialog.add(new JLabel("Salario Max:"), c);
        JTextField txtMax = new JTextField(10); c.gridx=1; dialog.add(txtMax, c);

        c.gridx=0;c.gridy=5; dialog.add(new JLabel("Ubicación:"), c);
        JTextField txtUbic = new JTextField(20); c.gridx=1; dialog.add(txtUbic, c);

        c.gridx=0;c.gridy=6; dialog.add(new JLabel("Modalidad:"), c);
        JComboBox<String> comboModalidad = new JComboBox<>(new String[]{"Presencial","Remoto","Híbrido"});
        c.gridx=1; dialog.add(comboModalidad, c);

        c.gridx=0;c.gridy=7; dialog.add(new JLabel("Tipo Contrato:"), c);
        JComboBox<String> comboContrato = new JComboBox<>(new String[]{"Tiempo completo","Medio tiempo","Freelance","Por proyecto"});
        c.gridx=1; dialog.add(comboContrato, c);

        JButton btnGuardar = new JButton("Guardar");
        c.gridy=8; c.gridx=0; c.gridwidth=2; dialog.add(btnGuardar, c);

        btnGuardar.addActionListener(e -> new Thread(() -> {
            try {
                PreparedStatement ps = getConn().prepareStatement(
                        "INSERT INTO vacantes (id_empresa,titulo,descripcion,requisitos,salario_min,salario_max,ubicacion,modalidad,tipo_contrato,estado) VALUES (?,?,?,?,?,?,?,?,?,'Activa')",
                        Statement.RETURN_GENERATED_KEYS
                );
                ps.setInt(1, getIdEmpresa());
                ps.setString(2, txtTitulo.getText());
                ps.setString(3, txtDesc.getText());
                ps.setString(4, txtReq.getText());
                ps.setDouble(5, Double.parseDouble(txtMin.getText()));
                ps.setDouble(6, Double.parseDouble(txtMax.getText()));
                ps.setString(7, txtUbic.getText());
                ps.setString(8, Objects.requireNonNull(comboModalidad.getSelectedItem()).toString());
                ps.setString(9, Objects.requireNonNull(comboContrato.getSelectedItem()).toString());
                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();
                int idVac = -1;
                if (keys.next()) idVac = keys.getInt(1);

                // Encolar en sistema concurrente (publicación de hilos)
                colaVacantes.enqueue(new VacantePublicado(idVac, getIdEmpresa(), txtTitulo.getText()));

                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(dialog, "Vacante agregada correctamente");
                    dialog.dispose();
                });
                cargarVacantesEmpresa(model);
            } catch (Exception ex) {
                ex.printStackTrace();
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(dialog, "Error al guardar la vacante: " + ex.getMessage()));
            }
        }).start());

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void cargarVacantesEmpresa(DefaultTableModel model) {
        try {
            PreparedStatement ps = getConn().prepareStatement("SELECT * FROM vacantes WHERE id_empresa=?");
            ps.setInt(1, getIdEmpresa());
            ResultSet rs = ps.executeQuery();
            DefaultTableModel nuevo = new DefaultTableModel(
                    new String[]{"ID","Titulo","Salario Min","Salario Max","Ubicación","Modalidad","Estado"}, 0);
            while(rs.next()) {
                nuevo.addRow(new Object[]{
                        rs.getInt("id_vacante"), rs.getString("titulo"), rs.getDouble("salario_min"),
                        rs.getDouble("salario_max"), rs.getString("ubicacion"), rs.getString("modalidad"), rs.getString("estado")
                });
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException ex) { ex.printStackTrace(); }
    }
    private void cargarAplicacionesEmpresa(DefaultTableModel model) {
        try {
            PreparedStatement ps = getConn().prepareStatement(
                    "SELECT a.id_aplicacion, p.nombre AS postulante, v.titulo AS vacante, a.estado " +
                            "FROM aplicaciones a " +
                            "JOIN postulantes p ON a.id_postulante=p.id_postulante " +
                            "JOIN vacantes v ON a.id_vacante=v.id_vacante " +
                            "WHERE v.id_empresa=?"
            );
            ps.setInt(1, getIdEmpresa());
            ResultSet rs = ps.executeQuery();
            DefaultTableModel nuevo = new DefaultTableModel(
                    new String[]{"ID Aplicación","Postulante","Vacante","Estado"}, 0);
            while(rs.next()) {
                nuevo.addRow(new Object[]{
                        rs.getInt("id_aplicacion"),
                        rs.getString("postulante"),
                        rs.getString("vacante"),
                        rs.getString("estado")
                });
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException ex) { ex.printStackTrace(); }
    }

    private void aceptarPostulante(JTable table, DefaultTableModel model) {
        int fila = table.getSelectedRow();
        if(fila == -1) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una aplicación"));
            return;
        }
        int idApp = (int) model.getValueAt(fila, 0);
        try {
            PreparedStatement ps = getConn().prepareStatement(
                    "UPDATE aplicaciones SET estado='Aceptada' WHERE id_aplicacion=?"
            );
            ps.setInt(1, idApp);
            ps.executeUpdate();
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Postulante aceptado"));
            cargarAplicacionesEmpresa(model);
        } catch(SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void rechazarPostulante(JTable table, DefaultTableModel model) {
        int fila = table.getSelectedRow();
        if(fila == -1) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una aplicación"));
            return;
        }
        int idApp = (int) model.getValueAt(fila, 0);
        try {
            PreparedStatement ps = getConn().prepareStatement(
                    "UPDATE aplicaciones SET estado='Rechazada' WHERE id_aplicacion=?"
            );
            ps.setInt(1, idApp);
            ps.executeUpdate();
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Postulante rechazado"));
            cargarAplicacionesEmpresa(model);
        } catch(SQLException ex) {
            ex.printStackTrace();
        }
    }

    // ------------------------ PANEL POSTULANTE ------------------------
    private void crearPostulantePanel(){
        postulantePanel = new JPanel(new BorderLayout());
        JTabbedPane tabbedPane = new JTabbedPane();

        // ---------------- PERFIL ----------------
        JPanel perfilPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);

        JLabel lblNombre = new JLabel();       c.gridx=1; c.gridy=0; perfilPanel.add(lblNombre, c);
        JLabel lblTelefono = new JLabel();     c.gridx=1; c.gridy=1; perfilPanel.add(lblTelefono, c);
        JLabel lblDireccion = new JLabel();    c.gridx=1; c.gridy=2; perfilPanel.add(lblDireccion, c);
        JLabel lblEstudios = new JLabel();     c.gridx=1; c.gridy=3; perfilPanel.add(lblEstudios, c);
        JLabel lblFecha = new JLabel();        c.gridx=1; c.gridy=4; perfilPanel.add(lblFecha, c);
        JLabel lblGenero = new JLabel();       c.gridx=1; c.gridy=5; perfilPanel.add(lblGenero, c);
        JLabel lblCv = new JLabel();           c.gridx=1; c.gridy=6; perfilPanel.add(lblCv, c);

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        c.gridy=7; c.gridx=0; c.gridwidth=2; perfilPanel.add(btnCerrarSesion, c);

        btnCerrarSesion.addActionListener(e -> {
            usuarioId = -1;
            mostrarLoginPanel();
        });

        tabbedPane.add("Perfil", perfilPanel);

        // Carga de datos fuera del EDT
        new Thread(() -> cargarDatosPostulante(lblNombre, lblTelefono, lblDireccion, lblEstudios, lblFecha, lblGenero, lblCv)).start();

        // ---------------- VACANTES DISPONIBLES ----------------
        JPanel vacantesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelVacantes = new DefaultTableModel();
        JTable tableVacantes = new JTable(modelVacantes);
        modelVacantes.setColumnIdentifiers(new String[]{"ID", "Título", "Empresa", "Salario Min", "Salario Max", "Ubicación", "Modalidad"});
        vacantesPanel.add(new JScrollPane(tableVacantes), BorderLayout.CENTER);

        JPanel panelBotonesVacantes = new JPanel();
        JButton btnAplicar = new JButton("Aplicar a Vacante");
        JButton btnRefrescarVacantes = new JButton("Refrescar");
        panelBotonesVacantes.add(btnAplicar);
        panelBotonesVacantes.add(btnRefrescarVacantes);
        vacantesPanel.add(panelBotonesVacantes, BorderLayout.SOUTH);

        btnAplicar.addActionListener(e -> new Thread(() -> {
            int row = tableVacantes.getSelectedRow();
            if(row >= 0){
                int idVacante = Integer.parseInt(tableVacantes.getValueAt(row, 0).toString());
                aplicarVacante(idVacante);
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Aplicación enviada"));
            } else {
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Seleccione una vacante primero"));
            }
        }).start());

        btnRefrescarVacantes.addActionListener(e -> new Thread(() -> cargarVacantes(modelVacantes)).start());

        tabbedPane.add("Vacantes", vacantesPanel);

        // ---------------- MIS APLICACIONES ----------------
        JPanel aplicacionesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelApps = new DefaultTableModel();
        JTable tableApps = new JTable(modelApps);
        modelApps.setColumnIdentifiers(new String[]{"ID", "Vacante", "Empresa", "Estado", "Fecha Aplicación"});
        aplicacionesPanel.add(new JScrollPane(tableApps), BorderLayout.CENTER);

        JPanel panelBotonesApps = new JPanel(new BorderLayout());
        JPanel botones = new JPanel();
        JButton btnRefrescarApps = new JButton("Refrescar");
        botones.add(btnRefrescarApps);
        panelBotonesApps.add(botones, BorderLayout.NORTH);
        aplicacionesPanel.add(panelBotonesApps, BorderLayout.SOUTH);

        btnRefrescarApps.addActionListener(e -> new Thread(() -> cargarAplicaciones(modelApps)).start());

        tabbedPane.add("Mis Aplicaciones", aplicacionesPanel);

        // ---------------- Agregar TabbedPane al panel ----------------
        postulantePanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(postulantePanel, "postulante");

        // ---------------- Cargar vacantes y aplicaciones ----------------
        new Thread(() -> cargarVacantes(modelVacantes)).start();
        new Thread(() -> cargarAplicaciones(modelApps)).start();
    }

    // ---------------- METODOS AUXILIARES POSTULANTE ----------------
    private void cargarDatosPostulante(JLabel nombre, JLabel tel, JLabel dir,
                                       JLabel estudios, JLabel fecha, JLabel genero, JLabel cv) {
        try {
            PreparedStatement ps = getConn().prepareStatement("SELECT * FROM postulantes WHERE id_usuario=?");
            ps.setInt(1, usuarioId);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                SwingUtilities.invokeLater(() -> {
                    nombre.setText(rsSafe(rs,"nombre"));
                    tel.setText(rsSafe(rs,"telefono"));
                    dir.setText(rsSafe(rs,"direccion"));
                    estudios.setText(rsSafe(rs,"nivel_estudios"));
                    fecha.setText(rsSafe(rs,"fecha_nacimiento"));
                    genero.setText(rsSafe(rs,"genero"));
                    cv.setText(rsSafe(rs,"cv_url"));
                });
            }
        } catch(SQLException ex) { ex.printStackTrace(); }
    }
    private static String rsSafe(ResultSet rs, String col){ try { return Objects.toString(rs.getString(col),""); } catch (SQLException e){ return ""; } }

    private void cargarAplicaciones(DefaultTableModel model){
        try{
            PreparedStatement ps = getConn().prepareStatement(
                    "SELECT a.id_aplicacion, v.titulo, e.nombre, a.estado, a.fecha_aplicacion " +
                            "FROM aplicaciones a " +
                            "JOIN vacantes v ON a.id_vacante = v.id_vacante " +
                            "JOIN empresas e ON v.id_empresa = e.id_empresa " +
                            "WHERE a.id_postulante=(SELECT id_postulante FROM postulantes WHERE id_usuario=?)"
            );
            ps.setInt(1, usuarioId);
            ResultSet rs = ps.executeQuery();
            DefaultTableModel nuevo = new DefaultTableModel(
                    new String[]{"ID", "Vacante", "Empresa", "Estado", "Fecha Aplicación"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5)
                });
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    private int getIdPostulante() {
        try {
            if (this.conn == null || this.conn.isClosed()) {
                conectarDB();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT id_postulante FROM postulantes WHERE id_usuario=?")) {
                ps.setInt(1, usuarioId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt("id_postulante");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            SwingUtilities.invokeLater(() ->
                    JOptionPane.showMessageDialog(this, "Error obteniendo id de postulante: " + ex.getMessage()));
        }
        return -1;
    }

    private void cargarVacantes(DefaultTableModel model){
        try{
            PreparedStatement ps = getConn().prepareStatement(
                    "SELECT v.id_vacante, v.titulo, e.nombre, v.salario_min, v.salario_max, v.ubicacion, v.modalidad " +
                            "FROM vacantes v JOIN empresas e ON v.id_empresa = e.id_empresa WHERE v.estado='Activa'"
            );
            ResultSet rs = ps.executeQuery();
            DefaultTableModel nuevo = new DefaultTableModel(
                    new String[]{"ID", "Título", "Empresa", "Salario Min", "Salario Max", "Ubicación", "Modalidad"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getDouble(4), rs.getDouble(5), rs.getString(6), rs.getString(7)
                });
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    private void aplicarVacante(int idVacante) {
        try {
            PreparedStatement ps = getConn().prepareStatement(
                    "INSERT INTO aplicaciones (id_postulante, id_vacante, mensaje, estado, estado_visto) " +
                            "VALUES ((SELECT id_postulante FROM postulantes WHERE id_usuario=?), ?, ?, 'Pendiente', 'Pendiente')",
                    Statement.RETURN_GENERATED_KEYS
            );
            ps.setInt(1, usuarioId);
            ps.setInt(2, idVacante);
            ps.setString(3, "");
            ps.executeUpdate();
            int idAplicacion = -1;
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) idAplicacion = keys.getInt(1);

            // Notificar a empresa (evento concurrente)
            int idPost = getIdPostulante();
            colaSolicitudes.enqueue(new SolicitudAplicacion(idAplicacion, idPost, idVacante));
            eventBus.publish("nueva-aplicacion", new SolicitudAplicacion(idAplicacion, idPost, idVacante));

        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    // ------------------------ PANEL ADMIN ------------------------
    private void crearAdminPanel() {
        adminPanel = new JPanel(new BorderLayout());
        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel perfilAdminPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);

// Botón Cerrar Sesión
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        c.gridx = 0;
        c.gridy = 0;
        perfilAdminPanel.add(btnCerrarSesion, c);

        btnCerrarSesion.addActionListener(e -> {
            usuarioId = -1;
            mostrarLoginPanel();
        });

// Agregar la pestaña de Perfil al tabbedPane del admin
        tabbedPane.add("Perfil", perfilAdminPanel);
        // ---------------- USUARIOS ----------------
        JPanel usuariosPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelUsuarios = new DefaultTableModel();
        JTable tableUsuarios = new JTable(modelUsuarios);
        modelUsuarios.setColumnIdentifiers(new String[]{"ID", "Email", "Tipo Usuario"});
        usuariosPanel.add(new JScrollPane(tableUsuarios), BorderLayout.CENTER);

        JPanel botonesUsuarios = new JPanel();
        JButton btnAgregarUsuario = new JButton("Agregar Usuario");
        JButton btnEditarUsuario = new JButton("Editar");
        JButton btnEliminarUsuario = new JButton("Eliminar");
        JButton btnRefrescarUsuarios = new JButton("Refrescar");
        botonesUsuarios.add(btnAgregarUsuario);
        botonesUsuarios.add(btnEditarUsuario);
        botonesUsuarios.add(btnEliminarUsuario);
        botonesUsuarios.add(btnRefrescarUsuarios);
        usuariosPanel.add(botonesUsuarios, BorderLayout.NORTH);

        btnAgregarUsuario.addActionListener(e -> new Thread(() -> mostrarDialogoAgregarUsuario(modelUsuarios)).start());
        btnRefrescarUsuarios.addActionListener(e -> new Thread(() -> cargarUsuarios(modelUsuarios)).start());

        btnEditarUsuario.addActionListener(e -> new Thread(() -> {
            int fila = tableUsuarios.getSelectedRow();
            if(fila == -1) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Selecciona un usuario para editar")); return; }
            int id = (int) modelUsuarios.getValueAt(fila, 0);
            String email = (String) modelUsuarios.getValueAt(fila, 1);
            String tipo = (String) modelUsuarios.getValueAt(fila, 2);
            SwingUtilities.invokeLater(() -> mostrarDialogoEditarUsuario(id, email, tipo, modelUsuarios));
        }).start());

        btnEliminarUsuario.addActionListener(e -> new Thread(() -> {
            int fila = tableUsuarios.getSelectedRow();
            if(fila == -1) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Selecciona un usuario para eliminar")); return; }
            int id = (int) modelUsuarios.getValueAt(fila, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "¿Seguro que deseas eliminar este usuario?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION){
                try {
                    PreparedStatement ps = getConn().prepareStatement("DELETE FROM usuarios WHERE id_usuario=?");
                    ps.setInt(1, id);
                    ps.executeUpdate();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente"));
                    cargarUsuarios(modelUsuarios);
                } catch(SQLException ex){ ex.printStackTrace(); }
            }
        }).start());

        tabbedPane.add("Usuarios", usuariosPanel);

        // ---------------- POSTULANTES ----------------
        JPanel postulantesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelPostulantes = new DefaultTableModel();
        JTable tablePostulantes = new JTable(modelPostulantes);
        modelPostulantes.setColumnIdentifiers(new String[]{"ID", "Nombre", "Teléfono", "Email"});
        postulantesPanel.add(new JScrollPane(tablePostulantes), BorderLayout.CENTER);

        JPanel botonesPostulantes = new JPanel();
        JButton btnEditarPostulante = new JButton("Editar");
        JButton btnEliminarPostulante = new JButton("Eliminar");
        JButton btnRefrescarPostulantes = new JButton("Refrescar");
        botonesPostulantes.add(btnEditarPostulante);
        botonesPostulantes.add(btnEliminarPostulante);
        botonesPostulantes.add(btnRefrescarPostulantes);
        postulantesPanel.add(botonesPostulantes, BorderLayout.NORTH);

        btnRefrescarPostulantes.addActionListener(e -> new Thread(() -> cargarPostulantes(modelPostulantes)).start());

        btnEditarPostulante.addActionListener(e -> new Thread(() -> {
            int fila = tablePostulantes.getSelectedRow();
            if(fila == -1) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Selecciona un postulante para editar")); return; }
            int id = (int) modelPostulantes.getValueAt(fila,0);
            String nombre = (String) modelPostulantes.getValueAt(fila,1);
            String telefono = (String) modelPostulantes.getValueAt(fila,2);
            String email = (String) modelPostulantes.getValueAt(fila,3);
            SwingUtilities.invokeLater(() -> mostrarDialogoEditarPostulante(id, nombre, telefono, email, modelPostulantes));
        }).start());

        btnEliminarPostulante.addActionListener(e -> new Thread(() -> {
            int fila = tablePostulantes.getSelectedRow();
            if(fila == -1) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona un postulante para eliminar")); return; }
            int id = (int) modelPostulantes.getValueAt(fila,0);
            int confirm = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar este postulante?","Confirmar Eliminación",JOptionPane.YES_NO_OPTION);
            if(confirm==JOptionPane.YES_OPTION){
                try{
                    PreparedStatement ps = getConn().prepareStatement("DELETE FROM usuarios WHERE id_usuario=(SELECT id_usuario FROM postulantes WHERE id_postulante=?)");
                    ps.setInt(1,id); ps.executeUpdate();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Postulante eliminado correctamente"));
                    cargarPostulantes(modelPostulantes);
                } catch(SQLException ex){ ex.printStackTrace(); }
            }
        }).start());

        tabbedPane.add("Postulantes", postulantesPanel);

        // ---------------- EMPRESAS ----------------
        JPanel empresasPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelEmpresas = new DefaultTableModel();
        JTable tableEmpresas = new JTable(modelEmpresas);
        modelEmpresas.setColumnIdentifiers(new String[]{"ID", "Nombre", "Razón Social", "Email"});
        empresasPanel.add(new JScrollPane(tableEmpresas), BorderLayout.CENTER);

        JPanel botonesEmpresas = new JPanel();
        JButton btnEditarEmpresa = new JButton("Editar");
        JButton btnEliminarEmpresa = new JButton("Eliminar");
        JButton btnRefrescarEmpresas = new JButton("Refrescar");
        botonesEmpresas.add(btnEditarEmpresa); botonesEmpresas.add(btnEliminarEmpresa); botonesEmpresas.add(btnRefrescarEmpresas);
        empresasPanel.add(botonesEmpresas, BorderLayout.NORTH);

        btnRefrescarEmpresas.addActionListener(e -> new Thread(() -> cargarEmpresas(modelEmpresas)).start());

        btnEditarEmpresa.addActionListener(e -> new Thread(() -> {
            try {
                PreparedStatement ps = getConn().prepareStatement(
                        "SELECT nombre, rfc, telefono, direccion, descripcion FROM empresas WHERE id_empresa=?"
                );
                ps.setInt(1, getIdEmpresa());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    SwingUtilities.invokeLater(() -> {
                        JDialog dialog = new JDialog(this, "Editar Empresa", true);
                        dialog.setSize(400, 350);
                        dialog.setLayout(new GridBagLayout());
                        GridBagConstraints c2 = new GridBagConstraints();
                        c2.insets = new Insets(5,5,5,5);

                        c2.gridx = 0; c2.gridy = 0;
                        dialog.add(new JLabel("Nombre:"), c2);
                        JTextField txtNombre = new JTextField(rsSafe(rs,"nombre"), 20);
                        c2.gridx = 1; dialog.add(txtNombre, c2);

                        c2.gridx = 0; c2.gridy = 1;
                        dialog.add(new JLabel("RFC:"), c2);
                        JTextField txtRfc = new JTextField(rsSafe(rs,"rfc"), 13);
                        c2.gridx = 1; dialog.add(txtRfc, c2);

                        c2.gridx = 0; c2.gridy = 2;
                        dialog.add(new JLabel("Teléfono:"), c2);
                        JTextField txtTelefono = new JTextField(rsSafe(rs,"telefono"), 20);
                        c2.gridx = 1; dialog.add(txtTelefono, c2);

                        c2.gridx = 0; c2.gridy = 3;
                        dialog.add(new JLabel("Dirección:"), c2);
                        JTextArea txtDireccion = new JTextArea(rsSafe(rs,"direccion"), 3, 20);
                        c2.gridx = 1; dialog.add(new JScrollPane(txtDireccion), c2);

                        c2.gridx = 0; c2.gridy = 4;
                        dialog.add(new JLabel("Descripción:"), c2);
                        JTextArea txtDescripcion = new JTextArea(rsSafe(rs,"descripcion"), 3, 20);
                        c2.gridx = 1; dialog.add(new JScrollPane(txtDescripcion), c2);

                        JButton btnGuardar = new JButton("Guardar");
                        c2.gridy = 5; c2.gridx = 0; c2.gridwidth = 2;
                        dialog.add(btnGuardar, c2);

                        btnGuardar.addActionListener(ae -> new Thread(() -> {
                            try {
                                PreparedStatement psUpdate = getConn().prepareStatement(
                                        "UPDATE empresas SET nombre=?, rfc=?, telefono=?, direccion=?, descripcion=? WHERE id_empresa=?"
                                );
                                psUpdate.setString(1, txtNombre.getText());
                                psUpdate.setString(2, txtRfc.getText());
                                psUpdate.setString(3, txtTelefono.getText());
                                psUpdate.setString(4, txtDireccion.getText());
                                psUpdate.setString(5, txtDescripcion.getText());
                                psUpdate.setInt(6, getIdEmpresa());
                                psUpdate.executeUpdate();
                                SwingUtilities.invokeLater(() -> {
                                    JOptionPane.showMessageDialog(dialog, "Empresa actualizada correctamente");
                                    dialog.dispose();
                                });
                            } catch (SQLException ex) { ex.printStackTrace(); }
                        }).start());

                        dialog.setLocationRelativeTo(this);
                        dialog.setVisible(true);
                    });
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }).start());

        btnEliminarEmpresa.addActionListener(e -> new Thread(() -> {
            int fila = tableEmpresas.getSelectedRow();
            if(fila == -1) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una empresa para eliminar")); return; }
            int idEmpresa = (int) modelEmpresas.getValueAt(fila,0);

            int confirm = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar esta empresa?","Confirmar Eliminación",JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION){
                try{
                    PreparedStatement psUser = getConn().prepareStatement("SELECT id_usuario FROM empresas WHERE id_empresa=?");
                    psUser.setInt(1, idEmpresa);
                    ResultSet rs = psUser.executeQuery();
                    if(rs.next()){
                        int idUsuario = rs.getInt("id_usuario");

                        PreparedStatement psEmp = getConn().prepareStatement("DELETE FROM empresas WHERE id_empresa=?");
                        psEmp.setInt(1, idEmpresa);
                        psEmp.executeUpdate();

                        PreparedStatement psUsr = getConn().prepareStatement("DELETE FROM usuarios WHERE id_usuario=?");
                        psUsr.setInt(1, idUsuario);
                        psUsr.executeUpdate();

                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Empresa eliminada correctamente"));
                        cargarEmpresas(modelEmpresas);
                    }
                } catch(SQLException ex){ ex.printStackTrace(); }
            }
        }).start());

        tabbedPane.add("Empresas", empresasPanel);

        // ---------------- VACANTES ----------------
        JPanel vacantesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelVacantes = new DefaultTableModel();
        JTable tableVacantes = new JTable(modelVacantes);
        modelVacantes.setColumnIdentifiers(new String[]{"ID", "Título", "Empresa", "Estado", "Salario"});
        vacantesPanel.add(new JScrollPane(tableVacantes), BorderLayout.CENTER);

        JPanel botonesVacantes = new JPanel();
        JButton btnEditarVacante = new JButton("Editar");
        JButton btnEliminarVacante = new JButton("Eliminar");
        JButton btnRefrescarVacantes = new JButton("Refrescar");
        botonesVacantes.add(btnEditarVacante); botonesVacantes.add(btnEliminarVacante); botonesVacantes.add(btnRefrescarVacantes);
        vacantesPanel.add(botonesVacantes, BorderLayout.NORTH);

        btnRefrescarVacantes.addActionListener(e -> new Thread(() -> cargarVacantesAdmin(modelVacantes)).start());

        btnEditarVacante.addActionListener(e -> new Thread(() -> {
            int fila = tableVacantes.getSelectedRow();
            if(fila==-1){ SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una vacante para editar")); return; }
            int id = (int) modelVacantes.getValueAt(fila,0);
            String titulo = (String) modelVacantes.getValueAt(fila,1);
            String estado = (String) modelVacantes.getValueAt(fila,3);
            String salario = (String) modelVacantes.getValueAt(fila,4);
            SwingUtilities.invokeLater(() -> mostrarDialogoEditarVacante(id, titulo, estado, salario, modelVacantes));
        }).start());

        btnEliminarVacante.addActionListener(e -> new Thread(() -> {
            int fila = tableVacantes.getSelectedRow();
            if(fila==-1){ SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una vacante para eliminar")); return; }
            int id = (int) modelVacantes.getValueAt(fila,0);
            int confirm = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar esta vacante?","Confirmar Eliminación",JOptionPane.YES_NO_OPTION);
            if(confirm==JOptionPane.YES_OPTION){
                try{
                    PreparedStatement ps = getConn().prepareStatement("DELETE FROM vacantes WHERE id_vacante=?");
                    ps.setInt(1,id); ps.executeUpdate();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Vacante eliminada correctamente"));
                    cargarVacantesAdmin(modelVacantes);
                } catch(SQLException ex){ ex.printStackTrace(); }
            }
        }).start());

        tabbedPane.add("Vacantes", vacantesPanel);

        // ---------------- APLICACIONES ----------------
        JPanel aplicacionesPanel = new JPanel(new BorderLayout());
        DefaultTableModel modelAplicaciones = new DefaultTableModel();
        JTable tableAplicaciones = new JTable(modelAplicaciones);
        modelAplicaciones.setColumnIdentifiers(new String[]{"ID", "Postulante", "Vacante", "Empresa", "Estado"});
        aplicacionesPanel.add(new JScrollPane(tableAplicaciones), BorderLayout.CENTER);

        JPanel botonesApps = new JPanel();
        JButton btnEditarApp = new JButton("Editar");
        JButton btnEliminarApp = new JButton("Eliminar");
        JButton btnRefrescarApps = new JButton("Refrescar");
        botonesApps.add(btnEditarApp); botonesApps.add(btnEliminarApp); botonesApps.add(btnRefrescarApps);
        aplicacionesPanel.add(botonesApps, BorderLayout.NORTH);

        btnRefrescarApps.addActionListener(e -> new Thread(() -> cargarAplicacionesAdmin(modelAplicaciones)).start());

        btnEditarApp.addActionListener(e -> new Thread(() -> {
            int fila = tableAplicaciones.getSelectedRow();
            if(fila==-1){ SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una aplicación para editar")); return; }
            int id = (int) modelAplicaciones.getValueAt(fila,0);
            String estado = (String) modelAplicaciones.getValueAt(fila,4);
            SwingUtilities.invokeLater(() -> mostrarDialogoEditarAplicacion(id, estado, modelAplicaciones));
        }).start());

        btnEliminarApp.addActionListener(e -> new Thread(() -> {
            int fila = tableAplicaciones.getSelectedRow();
            if(fila==-1){ SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Selecciona una aplicación para eliminar")); return; }
            int id = (int) modelAplicaciones.getValueAt(fila,0);
            int confirm = JOptionPane.showConfirmDialog(this,"¿Seguro que deseas eliminar esta aplicación?","Confirmar Eliminación",JOptionPane.YES_NO_OPTION);
            if(confirm==JOptionPane.YES_OPTION){
                try{
                    PreparedStatement ps = getConn().prepareStatement("DELETE FROM aplicaciones WHERE id_aplicacion=?");
                    ps.setInt(1,id); ps.executeUpdate();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,"Aplicación eliminada correctamente"));
                    cargarAplicacionesAdmin(modelAplicaciones);
                } catch(SQLException ex){ ex.printStackTrace(); }
            }
        }).start());

        tabbedPane.add("Aplicaciones", aplicacionesPanel);

        // ---------------- FINAL ----------------
        adminPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(adminPanel, "admin");

        // Cargar datos inicialmente en hilos
        new Thread(() -> cargarUsuarios(modelUsuarios)).start();
        new Thread(() -> cargarPostulantes(modelPostulantes)).start();
        new Thread(() -> cargarEmpresas(modelEmpresas)).start();
        new Thread(() -> cargarVacantesAdmin(modelVacantes)).start();
        new Thread(() -> cargarAplicacionesAdmin(modelAplicaciones)).start();
    }

    // ---------------- METODOS AUXILIARES ADMIN ----------------
    private void cargarUsuarios(DefaultTableModel model){
        try{
            Statement st = getConn().createStatement();
            ResultSet rs = st.executeQuery("SELECT id_usuario,email,tipo_usuario FROM usuarios");
            DefaultTableModel nuevo = new DefaultTableModel(new String[]{"ID","Email","Tipo Usuario"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3)});
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    private void cargarPostulantes(DefaultTableModel model){
        try{
            Statement st = getConn().createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT p.id_postulante, p.nombre, p.telefono, u.email " +
                            "FROM postulantes p JOIN usuarios u ON p.id_usuario = u.id_usuario"
            );
            DefaultTableModel nuevo = new DefaultTableModel(new String[]{"ID","Nombre","Teléfono","Email"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    private void cargarEmpresas(DefaultTableModel model){
        try{
            Statement st = getConn().createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT e.id_empresa, e.nombre, e.rfc, e.telefono, e.direccion, e.descripcion, u.email " +
                            "FROM empresas e JOIN usuarios u ON e.id_usuario = u.id_usuario"
            );
            DefaultTableModel nuevo = new DefaultTableModel(new String[]{
                    "ID","Nombre","Razón Social","Email"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{
                        rs.getInt("id_empresa"),
                        rs.getString("nombre"),
                        rs.getString("rfc"), // lo mostramos como Razón Social tal como tenías
                        rs.getString("email")
                });
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    private void cargarVacantesAdmin(DefaultTableModel model){
        try{
            Statement st = getConn().createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT v.id_vacante, v.titulo, e.nombre, v.estado, CONCAT(v.salario_min,'-',v.salario_max) " +
                            "FROM vacantes v JOIN empresas e ON v.id_empresa = e.id_empresa"
            );
            DefaultTableModel nuevo = new DefaultTableModel(new String[]{"ID","Título","Empresa","Estado","Salario"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    private void cargarAplicacionesAdmin(DefaultTableModel model){
        try{
            Statement st = getConn().createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT a.id_aplicacion, p.nombre, v.titulo, e.nombre, a.estado " +
                            "FROM aplicaciones a " +
                            "JOIN postulantes p ON a.id_postulante = p.id_postulante " +
                            "JOIN vacantes v ON a.id_vacante = v.id_vacante " +
                            "JOIN empresas e ON v.id_empresa = e.id_empresa"
            );
            DefaultTableModel nuevo = new DefaultTableModel(new String[]{"ID","Postulante","Vacante","Empresa","Estado"}, 0);
            while(rs.next()){
                nuevo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (int i=0; i<nuevo.getRowCount(); i++) {
                    Vector<?> row = nuevo.getDataVector().elementAt(i);
                    model.addRow(row.toArray());
                }
            });
        } catch(SQLException e){ e.printStackTrace(); }
    }

    // ---------------- DIALOGOS ----------------
    private void mostrarDialogoAgregarUsuario(DefaultTableModel modelUsuarios) {
        JPanel panel = new JPanel(new GridLayout(0,2,10,10));

        JTextField txtEmail = new JTextField();
        JPasswordField txtPassword = new JPasswordField();
        JComboBox<String> cbTipo = new JComboBox<>(new String[]{"postulante", "empresa", "admin"});

        panel.add(new JLabel("Email:"));
        panel.add(txtEmail);
        panel.add(new JLabel("Contraseña:"));
        panel.add(txtPassword);
        panel.add(new JLabel("Tipo de Usuario:"));
        panel.add(cbTipo);

        int option = JOptionPane.showConfirmDialog(this, panel, "Agregar Usuario", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if(option == JOptionPane.OK_OPTION) {
            String email = txtEmail.getText();
            String password = new String(txtPassword.getPassword());
            String tipo = (String) cbTipo.getSelectedItem();

            new Thread(() -> {
                try {
                    PreparedStatement ps = getConn().prepareStatement(
                            "INSERT INTO usuarios (email, password, tipo_usuario) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS
                    );
                    ps.setString(1, email);
                    ps.setString(2, password);
                    ps.setString(3, tipo);
                    ps.executeUpdate();

                    ResultSet rs = ps.getGeneratedKeys();
                    int idUsuario;
                    if(rs.next()) idUsuario = rs.getInt(1);
                    else {
                        idUsuario = -1;
                    }

                    if(Objects.equals(tipo, "postulante")) {
                        SwingUtilities.invokeLater(() -> mostrarDialogoDatosPostulante(idUsuario));
                    } else if(Objects.equals(tipo, "empresa")) {
                        SwingUtilities.invokeLater(() -> mostrarDialogoDatosEmpresa(idUsuario));
                    }

                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(this, "Usuario agregado correctamente");
                    });
                    cargarUsuarios(modelUsuarios);

                } catch(SQLException ex) {
                    ex.printStackTrace();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Error al agregar usuario: " + ex.getMessage()));
                }
            }).start();
        }
    }

    private void mostrarDialogoDatosPostulante(int idUsuario) {
        JPanel panel = new JPanel(new GridLayout(0,2,10,10));

        JTextField txtNombre = new JTextField();
        JTextField txtTelefono = new JTextField();
        JTextArea txtDireccion = new JTextArea(3,20);
        JComboBox<String> cbNivel = new JComboBox<>(new String[]{"Secundaria", "Preparatoria", "Licenciatura", "Maestría", "Doctorado"});
        JTextArea txtExperiencia = new JTextArea(3,20);
        JTextField txtCV = new JTextField();
        JTextField txtFecha = new JTextField();
        JComboBox<String> cbGenero = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro", "Prefiero no decir"});

        panel.add(new JLabel("Nombre:")); panel.add(txtNombre);
        panel.add(new JLabel("Teléfono:")); panel.add(txtTelefono);
        panel.add(new JLabel("Dirección:")); panel.add(new JScrollPane(txtDireccion));
        panel.add(new JLabel("Nivel de Estudios:")); panel.add(cbNivel);
        panel.add(new JLabel("Experiencia:")); panel.add(new JScrollPane(txtExperiencia));
        panel.add(new JLabel("CV URL:")); panel.add(txtCV);
        panel.add(new JLabel("Fecha Nacimiento (YYYY-MM-DD):")); panel.add(txtFecha);
        panel.add(new JLabel("Género:")); panel.add(cbGenero);

        int option = JOptionPane.showConfirmDialog(this, panel, "Datos Postulante", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if(option == JOptionPane.OK_OPTION) {
            new Thread(() -> {
                try {
                    PreparedStatement ps = getConn().prepareStatement(
                            "INSERT INTO postulantes (id_usuario, nombre, telefono, direccion, nivel_estudios, experiencia, cv_url, fecha_nacimiento, genero) VALUES (?,?,?,?,?,?,?,?,?)"
                    );
                    ps.setInt(1, idUsuario);
                    ps.setString(2, txtNombre.getText());
                    ps.setString(3, txtTelefono.getText());
                    ps.setString(4, txtDireccion.getText());
                    ps.setString(5, (String) cbNivel.getSelectedItem());
                    ps.setString(6, txtExperiencia.getText());
                    ps.setString(7, txtCV.getText());
                    ps.setString(8, txtFecha.getText());
                    ps.setString(9, (String) cbGenero.getSelectedItem());
                    ps.executeUpdate();
                } catch(SQLException ex) {
                    ex.printStackTrace();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Error al agregar postulante: " + ex.getMessage()));
                }
            }).start();
        }
    }

    private void mostrarDialogoDatosEmpresa(int idUsuario) {
        JPanel panel = new JPanel(new GridLayout(0,2,10,10));

        JTextField txtNombre = new JTextField();
        JTextField txtRFC = new JTextField();
        JTextField txtTelefono = new JTextField();
        JTextArea txtDireccion = new JTextArea(3,20);
        JTextArea txtDescripcion = new JTextArea(3,20);

        panel.add(new JLabel("Nombre:")); panel.add(txtNombre);
        panel.add(new JLabel("RFC:")); panel.add(txtRFC);
        panel.add(new JLabel("Teléfono:")); panel.add(txtTelefono);
        panel.add(new JLabel("Dirección:")); panel.add(new JScrollPane(txtDireccion));
        panel.add(new JLabel("Descripción:")); panel.add(new JScrollPane(txtDescripcion));

        int option = JOptionPane.showConfirmDialog(this, panel, "Datos Empresa", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if(option == JOptionPane.OK_OPTION) {
            new Thread(() -> {
                try {
                    PreparedStatement ps = getConn().prepareStatement(
                            "INSERT INTO empresas (id_usuario, nombre, rfc, telefono, direccion, descripcion) VALUES (?,?,?,?,?,?)"
                    );
                    ps.setInt(1, idUsuario);
                    ps.setString(2, txtNombre.getText());
                    ps.setString(3, txtRFC.getText());
                    ps.setString(4, txtTelefono.getText());
                    ps.setString(5, txtDireccion.getText());
                    ps.setString(6, txtDescripcion.getText());
                    ps.executeUpdate();
                } catch(SQLException ex) {
                    ex.printStackTrace();
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "Error al agregar empresa: " + ex.getMessage()));
                }
            }).start();
        }
    }

    private void mostrarDialogoEditarUsuario(int id, String email, String tipo, DefaultTableModel modelUsuarios) {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(adminPanel), "Editar Usuario", true);
        dialog.setSize(350,150);
        dialog.setLayout(new BorderLayout());

        JTextField txtEmail = new JTextField(email,20);
        JComboBox<String> comboTipo = new JComboBox<>(new String[]{"postulante","empresa","admin"});
        comboTipo.setSelectedItem(tipo);

        JPanel panelForm = new JPanel(new GridLayout(2,2,5,5));
        panelForm.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        panelForm.add(new JLabel("Email:")); panelForm.add(txtEmail);
        panelForm.add(new JLabel("Tipo:")); panelForm.add(comboTipo);
        dialog.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnGuardar); panelBotones.add(btnCancelar);
        dialog.add(panelBotones, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> new Thread(() -> {
            try {
                PreparedStatement ps = getConn().prepareStatement("UPDATE usuarios SET email=?, tipo_usuario=? WHERE id_usuario=?");
                ps.setString(1, txtEmail.getText());
                ps.setString(2, Objects.requireNonNull(comboTipo.getSelectedItem()).toString());
                ps.setInt(3, id);
                ps.executeUpdate();
                cargarUsuarios(modelUsuarios);
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(dialog,"Usuario actualizado correctamente");
                    dialog.dispose();
                });
            } catch(SQLException ex){ ex.printStackTrace(); }
        }).start());
        btnCancelar.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(adminPanel);
        dialog.setVisible(true);
    }

    private void mostrarDialogoEditarPostulante(int id, String nombre, String telefono, String email, DefaultTableModel modelPostulantes){
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(adminPanel), "Editar Postulante", true);
        dialog.setSize(400,200);
        dialog.setLayout(new BorderLayout());

        JTextField txtNombre = new JTextField(nombre,20);
        JTextField txtTelefono = new JTextField(telefono,20);
        JTextField txtEmail = new JTextField(email,20);

        JPanel panelForm = new JPanel(new GridLayout(3,2,5,5));
        panelForm.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        panelForm.add(new JLabel("Nombre:")); panelForm.add(txtNombre);
        panelForm.add(new JLabel("Teléfono:")); panelForm.add(txtTelefono);
        panelForm.add(new JLabel("Email:")); panelForm.add(txtEmail);
        dialog.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnGuardar); panelBotones.add(btnCancelar);
        dialog.add(panelBotones, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> new Thread(() -> {
            try {
                PreparedStatement ps1 = getConn().prepareStatement("UPDATE usuarios SET email=? WHERE id_usuario=(SELECT id_usuario FROM postulantes WHERE id_postulante=?)");
                ps1.setString(1, txtEmail.getText()); ps1.setInt(2,id); ps1.executeUpdate();
                PreparedStatement ps2 = getConn().prepareStatement("UPDATE postulantes SET nombre=?, telefono=? WHERE id_postulante=?");
                ps2.setString(1, txtNombre.getText()); ps2.setString(2, txtTelefono.getText()); ps2.setInt(3,id); ps2.executeUpdate();
                cargarPostulantes(modelPostulantes);
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(dialog,"Postulante actualizado correctamente");
                    dialog.dispose();
                });
            } catch(SQLException ex){ ex.printStackTrace(); }
        }).start());
        btnCancelar.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(adminPanel);
        dialog.setVisible(true);
    }



    private void mostrarDialogoEditarVacante(int id, String titulo, String estado, String salario, DefaultTableModel modelVacantes){
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(adminPanel), "Editar Vacante", true);
        dialog.setSize(400,200);
        dialog.setLayout(new BorderLayout());

        JTextField txtTitulo = new JTextField(titulo,20);
        JTextField txtEstado = new JTextField(estado,20);
        JTextField txtSalario = new JTextField(salario,20);

        JPanel panelForm = new JPanel(new GridLayout(3,2,5,5));
        panelForm.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        panelForm.add(new JLabel("Título:")); panelForm.add(txtTitulo);
        panelForm.add(new JLabel("Estado:")); panelForm.add(txtEstado);
        panelForm.add(new JLabel("Salario:")); panelForm.add(txtSalario);
        dialog.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnGuardar); panelBotones.add(btnCancelar);
        dialog.add(panelBotones, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> new Thread(() -> {
            try {
                String[] salarios = txtSalario.getText().split("-");
                double min=Double.parseDouble(salarios[0]);
                double max=Double.parseDouble(salarios[1]);
                PreparedStatement ps = getConn().prepareStatement("UPDATE vacantes SET titulo=?, estado=?, salario_min=?, salario_max=? WHERE id_vacante=?");
                ps.setString(1, txtTitulo.getText());
                ps.setString(2, txtEstado.getText());
                ps.setDouble(3, min);
                ps.setDouble(4, max);
                ps.setInt(5, id);
                ps.executeUpdate();
                cargarVacantesAdmin(modelVacantes);
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(dialog,"Vacante actualizada correctamente");
                    dialog.dispose();
                });
            } catch(Exception ex){ ex.printStackTrace(); SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(dialog,"Error en los datos")); }
        }).start());
        btnCancelar.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(adminPanel);
        dialog.setVisible(true);
    }

    private void mostrarDialogoEditarAplicacion(int id, String estado, DefaultTableModel modelAplicaciones){
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(adminPanel), "Editar Aplicación", true);
        dialog.setSize(300,150);
        dialog.setLayout(new BorderLayout());

        JTextField txtEstado = new JTextField(estado,20);

        JPanel panelForm = new JPanel(new GridLayout(1,2,5,5));
        panelForm.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        panelForm.add(new JLabel("Estado:")); panelForm.add(txtEstado);
        dialog.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnGuardar); panelBotones.add(btnCancelar);
        dialog.add(panelBotones, BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> new Thread(() -> {
            try {
                PreparedStatement ps = getConn().prepareStatement("UPDATE aplicaciones SET estado=? WHERE id_aplicacion=?");
                ps.setString(1, txtEstado.getText());
                ps.setInt(2, id);
                ps.executeUpdate();
                cargarAplicacionesAdmin(modelAplicaciones);
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(dialog,"Aplicación actualizada correctamente");
                    dialog.dispose();
                });
            } catch(SQLException ex){ ex.printStackTrace(); }
        }).start());
        btnCancelar.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(adminPanel);
        dialog.setVisible(true);
    }

    // -------------------- CONCURRENCIA: HILOS MANUALES --------------------
    private void startConcurrencySimulation() {
        // Hilo despachador de notificaciones basadas en la cola de solicitudes
        Thread notificador = new Thread(() -> {
            while (running) {
                try {
                    SolicitudAplicacion sa = colaSolicitudes.dequeue(); // bloquea hasta haber una
                    // Publica evento para mostrar notificación
                    eventBus.publish("nueva-aplicacion", sa);
                    // También podemos actualizar estado_visto si aplica
                    try {
                        PreparedStatement ps = getConn().prepareStatement(
                                "UPDATE aplicaciones SET estado_visto = estado WHERE id_aplicacion=?");
                        ps.setInt(1, sa.idAplicacion);
                        ps.executeUpdate();
                    } catch (SQLException ignored) {}
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "Notifier-Thread");
        notificador.start();
        workers.add(notificador);

        // Crear N empresas publicadoras
        int numEmpresas = 2;
        List<Integer> empresaIds = obtenerEmpresaIds();
        for (int i = 0; i < numEmpresas; i++) {
            int empresaId = empresaIds.isEmpty() ? -1 : empresaIds.get(i % empresaIds.size());
            Thread t = new EmpresaWorker(
                    "EmpresaWorker-" + (i + 1),
                    empresaId,
                    colaVacantes,
                    () -> { // Encapsulamos SQLException
                        try {
                            return getConn();
                        } catch (SQLException e) {
                            e.printStackTrace();
                            return null;
                        }
                    },
                    () -> { // Encapsulamos SQLException
                        refrescarTablasEmpresaYAdmin();
                    }
            );
            t.start();
            workers.add(t);
        }

// Crear M postulantes que aplican a lo que aparezca en la cola
        int numPostulantes = 3;
        List<Integer> postulanteIds = obtenerPostulanteIds();
        for (int i = 0; i < numPostulantes; i++) {
            int postId = postulanteIds.isEmpty() ? -1 : postulanteIds.get(i % postulanteIds.size());
            Thread t = new PostulanteWorker(
                    "PostulanteWorker-" + (i + 1),
                    postId,
                    colaVacantes,
                    colaSolicitudes,
                    () -> { // Encapsulamos SQLException
                        try {
                            return getConn();
                        } catch (SQLException e) {
                            e.printStackTrace();
                            return null;
                        }
                    }
            );
            t.start();
            workers.add(t);
        }

    }

    private List<Integer> obtenerEmpresaIds() {
        List<Integer> out = new ArrayList<>();
        try {
            ResultSet rs = getConn().createStatement().executeQuery("SELECT id_empresa FROM empresas");
            while (rs.next()) out.add(rs.getInt(1));
        } catch (SQLException e) { e.printStackTrace(); }
        return out;
    }

    private List<Integer> obtenerPostulanteIds() {
        List<Integer> out = new ArrayList<>();
        try {
            ResultSet rs = getConn().createStatement().executeQuery("SELECT id_postulante FROM postulantes");
            while (rs.next()) out.add(rs.getInt(1));
        } catch (SQLException e) { e.printStackTrace(); }
        return out;
    }

    private void refrescarTablasEmpresaYAdmin() {
        // Llamado desde hilos; delegamos a EDT si hay tablas visibles
        SwingUtilities.invokeLater(() -> {});
    }

    // -------------------- CLASES CONCURRENCIA AUX --------------------

    static class Notificacion {
        final String mensaje;
        final int idReferencia; // id de vacante o aplicación
        final long timestamp;

        Notificacion(String mensaje, int idReferencia) {
            this.mensaje = mensaje;
            this.idReferencia = idReferencia;
            this.timestamp = System.currentTimeMillis();
        }

        @Override
        public String toString() {
            return "[" + new java.util.Date(timestamp) + "] " + mensaje;
        }
    }



    // Cola segura con wait/notify (productor-consumidor)
    static class SafeQueue<T> {
        private final LinkedList<T> queue = new LinkedList<>();

        public synchronized void enqueue(T item) {
            queue.addLast(item);
            notifyAll(); // avisar a hilos esperando
        }

        public synchronized T dequeue() throws InterruptedException {
            while (queue.isEmpty()) wait();
            return queue.removeFirst();
        }

        public synchronized boolean isEmpty() {
            return queue.isEmpty();
        }
    }



    // Evento de publicación de una vacante (del hilo empresa a la cola)
    static class VacantePublicado {
        final int idVacante;
        final int idEmpresa;
        final String titulo;
        VacantePublicado(int idVacante, int idEmpresa, String titulo) {
            this.idVacante = idVacante;
            this.idEmpresa = idEmpresa;
            this.titulo = titulo;
        }
    }

    // Evento/solicitud de aplicación (del hilo postulante a la cola de notificaciones)
    static class SolicitudAplicacion {
        int idAplicacion;
        final int idPostulante;
        final int idVacante;
        public int postulanteId;
        public int vacanteId;

        SolicitudAplicacion(int idAplicacion, int idPostulante, int idVacante) {
            this.idAplicacion = idAplicacion;
            this.idPostulante = idPostulante;
            this.idVacante = idVacante;
        }
    }

    // Bus de eventos simple
    static class EventBus {
        private final Map<String, List<Subscriber>> subs = new HashMap<>();
        public synchronized void subscribe(String topic, Subscriber s) {
            subs.computeIfAbsent(topic, k -> new ArrayList<>()).add(s);
        }
        public void publish(String topic, Object payload) {
            List<Subscriber> ls;
            synchronized (this) { ls = subs.get(topic) == null ? List.of() : new ArrayList<>(subs.get(topic)); }
            for (Subscriber s : ls) {
                try { s.onEvent(payload); } catch (Exception ignored) {}
            }
        }
    }
    interface Subscriber { void onEvent(Object payload); }

    // Hilo de empresa que publica vacantes periódicamente
    // ====================== WORKER DE EMPRESA ======================
    class EmpresaWorker extends Thread {
        private final int empresaId;
        private final SafeQueue<VacantePublicado> colaVacantes;
        private final Supplier<Connection> connSupplier;
        private final Runnable refrescarCallback;

        public EmpresaWorker(String nombre, int empresaId,
                             SafeQueue<VacantePublicado> colaVacantes,
                             Supplier<Connection> connSupplier,
                             Runnable refrescarCallback) {
            super(nombre);
            this.empresaId = empresaId;
            this.colaVacantes = colaVacantes;
            this.connSupplier = connSupplier;
            this.refrescarCallback = refrescarCallback;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    // Simula que la empresa publica una vacante cada 1 minuto
                    Thread.sleep(60000);

                    Connection conn = connSupplier.get();
                    if (conn != null && empresaId != -1) {
                        String sql = "INSERT INTO vacantes(titulo, descripcion, id_empresa) VALUES(?,?,?)";
                        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                            ps.setString(1, "Vacante de prueba");
                            ps.setString(2, "Descripción generada por " + getName());
                            ps.setInt(3, empresaId);
                            ps.executeUpdate();

                            try (ResultSet rs = ps.getGeneratedKeys()) {
                                if (rs.next()) {
                                    int vacanteId = rs.getInt(1);
                                    VacantePublicado v = new VacantePublicado(vacanteId, empresaId, "Vacante de prueba");
                                    colaVacantes.enqueue(v); // Encolamos para postulantes

                                    // Notificación visual
                                    SwingUtilities.invokeLater(() ->
                                            JOptionPane.showMessageDialog(null,
                                                    "Nueva vacante publicada por " + getName())
                                    );

                                    // Refrescar tablas de la UI si hay callback
                                    if (refrescarCallback != null) refrescarCallback.run();
                                }
                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            } catch (InterruptedException e) {
                System.out.println(getName() + " detenido.");
            }
        }
    }

    // ====================== WORKER DE POSTULANTE ======================
    class PostulanteWorker extends Thread {
        private final int postulanteId;
        private final SafeQueue<VacantePublicado> colaVacantes;
        private final SafeQueue<SolicitudAplicacion> colaSolicitudes;
        private final Supplier<Connection> connSupplier;

        public PostulanteWorker(String nombre, int postulanteId,
                                SafeQueue<VacantePublicado> colaVacantes,
                                SafeQueue<SolicitudAplicacion> colaSolicitudes,
                                Supplier<Connection> connSupplier) {
            super(nombre);
            this.postulanteId = postulanteId;
            this.colaVacantes = colaVacantes;
            this.colaSolicitudes = colaSolicitudes;
            this.connSupplier = connSupplier;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    // Espera hasta que haya una vacante disponible
                    VacantePublicado vac = colaVacantes.dequeue();

                    // Simula tiempo de análisis/aplicación: 1 minuto
                    Thread.sleep(60000);

                    // Crear la solicitud; MySQL asignará id_aplicacion automáticamente
                    SolicitudAplicacion app = new SolicitudAplicacion(0, postulanteId, vac.idVacante);
                    colaSolicitudes.enqueue(app); // Encolamos localmente

                    // Guardar en DB
                    try (Connection c = connSupplier.get()) {
                        if (c != null) {
                            String sql = "INSERT INTO aplicaciones (id_postulante, id_vacante) VALUES (?, ?)";
                            try (PreparedStatement ps = c.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                                ps.setInt(1, app.idPostulante);
                                ps.setInt(2, app.idVacante);
                                ps.executeUpdate();

                                try (ResultSet rs = ps.getGeneratedKeys()) {
                                    if (rs.next()) {
                                        app.idAplicacion = rs.getInt(1); // actualizar ID en objeto
                                    }
                                }
                            }
                        }
                    }

                    System.out.println(getName() + " aplicó a #" + vac.idVacante + " -> app #" + app.idAplicacion);
                }
            } catch (InterruptedException e) {
                System.out.println(getName() + " detenido.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }






    @FunctionalInterface
    interface DBProvider { Connection get() throws SQLException; }

    // -------------------- MAIN --------------------
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}