package com.sistema_vacantes.concurrente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.function.Supplier;

public class EmpresaWorker extends Thread {
    private final int empresaId;
    private final BlockingQueue<Vacante> colaVacantes;
    private final Supplier<Connection> connSupplier;
    private final Runnable notificador;
    private final Random random = new Random();

    public EmpresaWorker(String nombre, int empresaId,
                         BlockingQueue<Vacante> colaVacantes,
                         Supplier<Connection> connSupplier,
                         Runnable notificador) {
        super(nombre);
        this.empresaId = empresaId;
        this.colaVacantes = colaVacantes;
        this.connSupplier = connSupplier;
        this.notificador = notificador;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(60_000); // Espera 1 minuto
                Vacante vacante = new Vacante("Vacante_" + System.currentTimeMillis(), empresaId);
                colaVacantes.put(vacante);

                // Guardar en BD
                try (Connection conn = connSupplier.get()) {
                    String sql = "INSERT INTO vacantes (titulo, id_empresa) VALUES (?, ?)";
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setString(1, vacante.getTitulo());
                        ps.setInt(2, empresaId);
                        ps.executeUpdate();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

                // Notificar refresco a la UI
                notificador.run();
                System.out.println(getName() + " publicó: " + vacante.getTitulo());
            }

        } catch (InterruptedException e) {
            System.out.println(getName() + " detenido.");
        }
    }
}
