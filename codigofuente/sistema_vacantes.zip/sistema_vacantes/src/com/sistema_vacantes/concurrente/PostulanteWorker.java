package com.sistema_vacantes.concurrente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.function.Supplier;

public class PostulanteWorker extends Thread {
    private final int postulanteId;
    private final BlockingQueue<Vacante> colaVacantes;
    private final BlockingQueue<Solicitud> colaSolicitudes;
    private final Supplier<Connection> connSupplier;
    private final Random random = new Random();

    public PostulanteWorker(String nombre, int postulanteId,
                            BlockingQueue<Vacante> colaVacantes,
                            BlockingQueue<Solicitud> colaSolicitudes,
                            Supplier<Connection> connSupplier) {
        super(nombre);
        this.postulanteId = postulanteId;
        this.colaVacantes = colaVacantes;
        this.colaSolicitudes = colaSolicitudes;
        this.connSupplier = connSupplier;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // Esperar a que aparezca una vacante en la cola
                Vacante vacante = colaVacantes.take();

                // Esperar 1 minuto antes de aplicar
                Thread.sleep(60_000);

                Solicitud solicitud = new Solicitud(postulanteId, vacante);
                colaSolicitudes.put(solicitud);

                // Guardar en BD
                try (Connection conn = connSupplier.get()) {
                    String sql = "INSERT INTO solicitudes (id_postulante, id_vacante) VALUES (?, ?)";
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setInt(1, postulanteId);
                        ps.setInt(2, vacante.getId());
                        ps.executeUpdate();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

                System.out.println(getName() + " aplicó a: " + vacante.getTitulo());
            }

        } catch (InterruptedException e) {
            System.out.println(getName() + " detenido.");
        }
    }
}
