package com.sistema_vacantes.concurrente;

public class Solicitud {
    private final int postulanteId;
    private final Vacante vacante;

    public Solicitud(int postulanteId, Vacante vacante) {
        this.postulanteId = postulanteId;
        this.vacante = vacante;
    }

    public int getPostulanteId() { return postulanteId; }
    public Vacante getVacante() { return vacante; }
}
