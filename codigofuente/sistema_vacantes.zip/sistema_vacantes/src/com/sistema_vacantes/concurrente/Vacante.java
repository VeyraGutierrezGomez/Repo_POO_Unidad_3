package com.sistema_vacantes.concurrente;

public class Vacante {
    private static int counter = 1;
    private final int id;
    private final String titulo;
    private final int empresaId;

    public Vacante(String titulo, int empresaId) {
        this.id = counter++;
        this.titulo = titulo;
        this.empresaId = empresaId;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public int getEmpresaId() { return empresaId; }
}
