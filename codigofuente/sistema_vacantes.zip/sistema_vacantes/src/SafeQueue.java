import java.util.LinkedList;

// Cola segura para múltiples hilos
public class SafeQueue<T> {
    private final LinkedList<T> queue = new LinkedList<>();

    // Método para añadir elemento a la cola
    public synchronized void enqueue(T item) {
        queue.addLast(item);
        notifyAll(); // despierta hilos que esperan
    }

    // Método para sacar elemento de la cola (bloqueante)
    public synchronized T dequeue() throws InterruptedException {
        while (queue.isEmpty()) {
            wait(); // espera hasta que haya un elemento
        }
        return queue.removeFirst();
    }

    public synchronized boolean isEmpty() {
        return queue.isEmpty();
    }
}
